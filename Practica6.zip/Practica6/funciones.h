#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "lista.h"
// Ramificacion y poda
void AsignacionTrivial(int B[][N], NODO *s, int *nNodos);
void AsignacionPrecisa(int B[][N], NODO *s, int *nNodos);

void BE(NODO *x);
void CI_trivial(NODO *x);
void CS_trivial(NODO *x, int B[][N]);
void CI_precisa(NODO *x, int B[][N]);
void CS_precisa(NODO *x, int B[][N]);

int Solucion(NODO x);
NODO Seleccionar(TLISTA *LNV);

int _AsignacionVoraz(NODO x, int B[][N]);
int _MaximosTareas(NODO x, int B[][N]);
NODO _SolAsignacionVoraz(NODO x, int B[][N], int *nNodos);

// ----------------------------------------

// Bactraking

void Backtracking(int B[][N], NODO *s, int *nNodos,
    unsigned long *criterio, unsigned long *generar, unsigned long *solucion,
    unsigned long *mashermanos, unsigned long *retroceder); // Función principal optimizada
// Funciones genéricas del esquema de Backtracking (con vector usadas)
void Generar_BT(NODO *x, int B[][N], int t_sig);
int Criterio_BT(NODO x);
int Solucion_BT(NODO x);
int MasHermanos_BT(NODO x);
void Retroceder_BT(NODO *x, int B[][N]);

// --- Nuevas declaraciones para Backtracking SIN vector usadas ---
void Backtracking_Lento(int B[][N], NODO *s, int *nNodos,
    unsigned long *criterio, unsigned long *generar, unsigned long *solucion,
    unsigned long *mashermanos, unsigned long *retroceder); // Función principal lentaint Criterio_Lento(NODO x);
void Retroceder_Lento(NODO *x, int B[][N], unsigned long *retroceder);
#endif
