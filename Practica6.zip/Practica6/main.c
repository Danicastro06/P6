/*
Hecho : Estan implementados todos los tipos de datos de la lista.
Toda la logica de ramificacion y poda esta hecha y da su salida con N=3. igual que en el
enunciado.
Main modificado para mejorar la salida ya estaria bien hecho

Restante: Queda por acabar de implementar las funciones de bactraking de ambos tanto con el vector usadas
como sin el vector usadas. Queda tambien por hacer los cambios en el informe del drive
solo estan hechos los de la matriz N=6 de RyP
*/



#include <stdio.h>
#include "lista.h"
#include "funciones.h"

int main() {


    int B[N][N] = {{4, 9, 1},{7, 2, 3},{6, 3, 5}};

    /*
     int B [N][N] = {{11, 17, 8, 16, 20, 14},
                     {9, 7, 6, 12, 15, 18},
                     {13, 15, 16, 12, 16, 18},
                     {21, 24, 28, 17, 26, 20},
                     {10, 14, 12, 11, 15, 13},
                     {12, 20, 19, 13, 22, 17} };
    */

    NODO s;          // solución devuelta por cada algoritmo
    int nNodos = 0;  // número de nodos explorados
    unsigned long c_criterio, c_generar, c_solucion, c_mashermanos, c_retroceder;

    nNodos = 0;      // contador a cero antes de llamar
    Backtracking_Lento(B, &s, &nNodos,
                           &c_criterio, &c_generar, &c_solucion,
                           &c_mashermanos, &c_retroceder);
    printf("BACKTRACKING SIN VECTOR USADAS:\n ");

    printf("\nNodos explorados = %d\n", nNodos);
    printf("Numero de pasos de cada función:\n");
    printf("\tPasos Criterio: %lu\n", c_criterio);
    printf("\tPasos Generar: %lu\n", c_generar);
    printf("\tPasos Solución: %lu\n", c_solucion);
    printf("\tPasos MasHermanos: %lu\n", c_mashermanos);
    printf("\tPasos Retroceder: %lu\n\n", c_retroceder);
    printf("Solucion:\n ");
    for (int i = 0; i < N; i++) {
        printf("Persona %i --> %d\n ",i, s.tupla[i]);

    }
    printf("\n\tBeneficio = %d\n", s.bact);

    printf("\n=====================================\n");

    nNodos = 0;      // contador a cero antes de llamar
    Backtracking(B, &s, &nNodos,
                     &c_criterio, &c_generar, &c_solucion,
                     &c_mashermanos, &c_retroceder);
    printf("\nBACKTRACKING CON VECTOR USADAS:\n ");

    printf("\nNodos explorados = %d\n", nNodos);
    printf("Numero de pasos de cada función:\n");
    printf("\tPasos Criterio: %lu\n", c_criterio);
    printf("\tPasos Generar: %lu\n", c_generar);
    printf("\tPasos Solución: %lu\n", c_solucion);
    printf("\tPasos MasHermanos: %lu\n", c_mashermanos);
    printf("\tPasos Retroceder: %lu\n\n", c_retroceder);
    printf("Solucion:\n ");
    for (int i = 0; i < N; i++) {
        printf("Persona %i --> %d\n ",i, s.tupla[i]);

    }
    printf("\n\tBeneficio = %d\n", s.bact);


    printf("\n=====================================\n");

    nNodos = 0;
    AsignacionTrivial(B, &s, &nNodos);

    printf("\nSolución TRIVIAL\n");
    printf("\nBeneficio = %d\n", s.bact);
    printf("Nodos explorados = %d\n\n", nNodos);
    printf("Solución:\n ");
    for (int i = 0; i < N; i++) {
        printf("Persona %i --> %d\n ",i, s.tupla[i]);
    }

    printf("\n=====================================\n");

    nNodos = 0;
    AsignacionPrecisa(B, &s, &nNodos);

    printf("\nSolución PRECISA\n");
    printf("\nBeneficio = %d\n", s.bact);
    printf("Nodos explorados = %d\n", nNodos);
    printf("Solución:\n ");
    for (int i = 0; i < N; i++) {
        printf("Persona %i --> %d\n ",i, s.tupla[i]);
    }

    return 0;
}
