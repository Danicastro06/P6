#include "funciones.h"
#include "lista.h"
#include <math.h>

// FUNCIONES AUXILIARES

// Calcula el maximo de la matriz
int max_matrix(int B[][N]) {
    int max = B[0][0];
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (B[i][j] > max) {
                max = B[i][j];
            }
        }
    }
    return max;
}

/// Beneficio estimado (BE) como la media entre CI y CS
void BE(NODO *x) {
    x->BE = (x->CI + x->CS) / 2.0;
}

/// Cota inferior trivial (CI)
void CI_trivial(NODO *x) {
    x->CI = x->bact;
}

/// Cota superior trivial (CS)
void CS_trivial(NODO *x, int B[][N]) {
    float cs = x->bact;
    int max_val = max_matrix(B);
    x->CS = cs + (N - x->nivel - 1) * max_val;
}

void CI_precisa(NODO *x, int B[][N]) {
    x->CI = x->bact + _AsignacionVoraz(*x, B);
}

void CS_precisa(NODO *x, int B[][N]) {
    x->CS = x->bact + _MaximosTareas(*x, B);
}

int Solucion(NODO x) {
    return (x.nivel == N - 1);
}

int _AsignacionVoraz(NODO x, int B[][N]) {
    int bacum = 0;
    for (int i = x.nivel + 1; i < N; i++) {
        int mejor = -1;
        int tbest = -1;
        for (int j = 0; j < N; j++) {
            if (!x.usadas[j] && B[i][j] > mejor) {
                mejor = B[i][j];
                tbest = j;
            }
        }
        if (tbest != -1) {
            x.usadas[tbest] = 1;
            bacum += mejor;
        }
    }
    return bacum;
}

int _MaximosTareas(NODO x, int B[][N]) {
    int bacum = 0;
    for (int i = x.nivel + 1; i < N; i++) {
        int best = -1;
        for (int j = 0; j < N; j++) {
            if (!x.usadas[j] && B[i][j] > best) {
                best = B[i][j];
            }
        }
        bacum += best;
    }
    return bacum;
}

NODO _SolAsignacionVoraz(NODO x, int B[][N], int * nNodos) {
    int Bmax    // Para cada fila
       ,tmax;   // para cada nivel

    for (int i = x.nivel + 1; i < N ; i++) {
        Bmax = -1;
        for (int j = 0; j < N ; j++) {
            if (!x.usadas[j] && B[i][j] > Bmax) {
                Bmax = B[i][j];
                tmax = j;
            }
        }
        x.tupla[i] = tmax;
        x.usadas[tmax] = 1;
        x.bact += Bmax;
        (*nNodos) ++;
        x.n = (*nNodos);
    }
    x.nivel = N - 1;
    return x;
}

// SELECCIONAR: ESTRATEGIA MB-LIFO
NODO Seleccionar(TLISTA *LNV) {
    TPOSICION p = primeroLista(*LNV);
    TPOSICION mejor = p;
    NODO x, candidato;
    recuperarElementoLista(*LNV, p, &x);
    while ((p = siguienteLista(*LNV, p)) != finLista(*LNV)) {
        recuperarElementoLista(*LNV, p, &candidato);
        if (candidato.BE > x.BE) {
            x = candidato;
            mejor = p;
        }
    }
    suprimirElementoLista(LNV, mejor);
    return x;
}

// ASIGNACION TRIVIAL
void AsignacionTrivial(int B[][N], NODO *s, int  *nNodos) {
    TLISTA LNV;
    NODO raiz, x, y;
    float C = 0;

    raiz.nivel = -1;
    raiz.bact = 0;
    for (int i = 0; i < N; i++) {
        raiz.tupla[i] = -1;
        raiz.usadas[i] = 0;
    }
    CI_trivial(&raiz);
    CS_trivial(&raiz, B);
    BE(&raiz);
    raiz.n = 1;

    s->bact = -1;
    C = raiz.CI;


    crearLista(&LNV);

    insertarElementoLista(&LNV, primeroLista(LNV), raiz);
    *nNodos = 1;
    while (!esListaVacia(LNV)) {
        x = Seleccionar(&LNV);
        if (x.CS > C) {
            for (int i = 0; i < N; i++) {
                y = x;
                y.nivel = x.nivel + 1;
                if (!x.usadas[i]) {
                    y.tupla[y.nivel] = i;
                    y.usadas[i] = 1;
                    y.bact = x.bact + B[y.nivel][i];
                    CI_trivial(&y);
                    CS_trivial(&y, B);
                    BE(&y);
                    (*nNodos) ++;
                    y.n = (*nNodos);
                    if (Solucion(y) && y.bact > s->bact) {
                        *s = y;
                        C = fmax(C,s->bact);
                    } else if (!Solucion(y) && y.CS > C) {
                        insertarElementoLista(&LNV, primeroLista(LNV), y);
                        C = fmax(C,y.CI);
                    }
                }
            }
        }
    }
    destruirLista(&LNV);
}

// ASIGNACION PRECISA
void AsignacionPrecisa(int B[][N], NODO *s, int *nNodos) {
    TLISTA LNV;
    NODO raiz, x, y;
    float C = 0;

    raiz.nivel = -1;
    raiz.bact = 0;
    for (int i = 0; i < N; i++) {
        raiz.tupla[i] = -1;
        raiz.usadas[i] = 0;
    }
    CI_precisa(&raiz, B);
    CS_precisa(&raiz, B);
    BE(&raiz);
    raiz.n = 1;

    s->bact = -1;
    C = raiz.CI;

    crearLista(&LNV);

    insertarElementoLista(&LNV, primeroLista(LNV), raiz);
    *nNodos = 1;
    while (!esListaVacia(LNV)) {
        x = Seleccionar(&LNV);
        if (x.CS > C) {
            for (int i = 0; i < N; i++) {
                y = x;
                y.nivel = x.nivel + 1;
                if (!x.usadas[i]) {

                    y.tupla[y.nivel] = i;
                    y.usadas[i] = 1;
                    y.bact = x.bact + B[y.nivel][i];
                    CI_precisa(&y, B);
                    CS_precisa(&y, B);
                    BE(&y);
                    (*nNodos) ++;
                    y.n = (*nNodos);

                    if (!Solucion(y) && y.CS >= C && y.CS == y.CI) {
                        y = _SolAsignacionVoraz(y, B, nNodos);
                        if (y.bact > s->bact) {
                            *s = y;
                            C = fmax(C,y.bact);
                        }
                        continue;
                    }
                    if (Solucion(y) && y.bact > s->bact) {
                        *s = y;
                        C = fmax(C, s->bact);
                    } else if (!Solucion(y) && y.CS > C) {
                        insertarElementoLista(&LNV, primeroLista(LNV), y);
                        C = fmax(C, y.CI);
                    }
                }
            }

        }else if (x.CS == C && x.CS==x.CI) {
            *s = _SolAsignacionVoraz(x, B, nNodos);
        }
    }
    destruirLista(&LNV);
}

// =======================================================
// === FUNCIONES GENÉRICAS DE BACKTRACKING (CON USADAS) ===
// =======================================================

// Generar(nivel,s) → probar la siguiente tarea
void Generar_BT(NODO *x, int B[][N], int t_sig) {
    // 1. Deshacer la asignación previa (si existe) y actualizar el beneficio
    if (x->tupla[x->nivel] != -1) {
        // Decrementar el contador de uso de la tarea anterior
        x->usadas[x->tupla[x->nivel]]--;
        // Restar el beneficio de la tarea anterior (B[nivel][tarea_anterior])
        x->bact -= B[x->nivel][x->tupla[x->nivel]];
    }

    // 2. Intentar la siguiente tarea
    x->tupla[x->nivel] = t_sig; // t_sig es el valor de la nueva tarea

    // 3. Actualizar el estado con la nueva tarea
    x->usadas[t_sig]++; // Incrementar el contador de uso de la nueva tarea
    // Sumar el beneficio de la nueva tarea
    x->bact += B[x->nivel][t_sig];
}

int Criterio_BT(NODO x) {
    return (x.usadas[x.tupla[x.nivel]] == 1);
}

int Solucion_BT(NODO x) {
    return (x.nivel == N - 1 && Criterio_BT(x));
}

// MasHermanos (nivel, s) → quedan asignaciones por probar
int MasHermanos_BT(NODO x) {
    // Si la tarea actual asignada es menor que N-1, quedan más tareas (hermanos) por probar.
    return (x.tupla[x.nivel] < N - 1);
}

// Retroceder(nivel,s)→deshacer la asignación previa y retroceder nivel
void Retroceder_BT(NODO *x, int B[][N]) {
    // 1. Deshacer el beneficio y el uso
    x->bact -= B[x->nivel][x->tupla[x->nivel]];
    x->usadas[x->tupla[x->nivel]]--;

    // 2. Restablecer el valor inicial (-1) y el nivel
    x->tupla[x->nivel] = -1;
    x->nivel--;
}
// =======================================================
// === ALGORITMO PRINCIPAL DE BACKTRACKING (CON USADAS) ===
// =======================================================

void Backtracking(int B[][N], NODO *s, int *nNodos,
    unsigned long *criterio, unsigned long *generar, unsigned long *solucion,
    unsigned long *mashermanos, unsigned long *retroceder) {

    NODO x;
    int voa = -1;
    int nivel = 0;

    *criterio = 0;
    *generar = 0;
    *solucion = 0;
    *mashermanos = 0;
    *retroceder = 0;

    x.nivel = 0;
    x.bact = 0;
    for (int i = 0; i < N; i++) {
        x.tupla[i] = -1;
        x.usadas[i] = 0;
    }
    s->bact = -1;
    x.tupla[x.nivel] = -1;

    do {
        int tarea_siguiente = x.tupla[nivel] + 1;

        if (tarea_siguiente < N) {
            *generar += 1;

            Generar_BT(&x, B, tarea_siguiente);

            *criterio += 1;
            if (Criterio_BT(x)) {
                (*nNodos)++;
                *solucion += 1;
                if (Solucion_BT(x) && (x.bact > voa)) {
                    voa = x.bact;
                    *s = x;
                }
                *criterio += 1;
                if (Criterio_BT(x) && (x.nivel < N - 1)) {
                    nivel++;
                    x.nivel = nivel;
                    x.tupla[nivel] = -1;
                }
            }
        } else {
            while (nivel >= 0 && x.tupla[nivel] == N - 1) {
                *retroceder += 1;
                Retroceder_BT(&x, B);
                nivel = x.nivel;
                *mashermanos += 1;
                if (nivel == 0 && !MasHermanos_BT(x)) break;
            }
        }
    } while (nivel >= 0);
}// Modifica Generar_Lento para seguir el pseudocódigo y contar
void Generar_Lento(NODO *x, int B[][N], unsigned long *generar) {
    *generar += 1;  // Incrementa por cada llamada a Generar
    x->tupla[x->nivel] += 1;  // s[nivel] = s[nivel] + 1
    if (x->tupla[x->nivel] == 0) {
        x->bact += B[x->nivel][x->tupla[x->nivel]];
    } else {
        x->bact += B[x->nivel][x->tupla[x->nivel]] - B[x->nivel][x->tupla[x->nivel] - 1];
    }
    // Nota: En variante lenta, usadas no se usa para criterio, pero lo mantenemos por consistencia
    x->usadas[x->tupla[x->nivel]]++;
}

// Modifica Criterio_Lento para contar
int Criterio_Lento(NODO x, unsigned long *criterio) {
    *criterio += 1;  // Incrementa por cada llamada
    for (int i = 0; i < x.nivel; i++) {
        if (x.tupla[x.nivel] == x.tupla[i]) {
            return 0;
        }
    }
    return 1;
}

// Solucion_BT ya existe, pero modifícalo para contar (o crea uno nuevo si usas Criterio_Lento)
int Solucion_Lento(NODO x, unsigned long *solucion, unsigned long *criterio) {
    *solucion += 1;  // Incrementa por cada check de Solución
    return (x.nivel == N - 1 && Criterio_Lento(x, criterio));  // Llama a Criterio y cuenta ahí
}

// MasHermanos_BT ya cuenta, pero modifícalo
int MasHermanos_Lento(NODO x, unsigned long *mashermanos) {
    *mashermanos += 1;  // Incrementa por cada check
    return (x.tupla[x.nivel] < N - 1);
}

// Retroceder_Lento ya existe, modifícalo para contar
void Retroceder_Lento(NODO *x, int B[][N], unsigned long *retroceder) {
    *retroceder += 1;  // Incrementa por cada llamada
    x->bact -= B[x->nivel][x->tupla[x->nivel]];
    x->tupla[x->nivel] = -1;
    x->nivel--;
}

// Ahora, Backtracking_Lento siguiendo exactamente el pseudocódigo
void Backtracking_Lento(int B[][N], NODO *s, int *nNodos,
    unsigned long *criterio, unsigned long *generar, unsigned long *solucion,
    unsigned long *mashermanos, unsigned long *retroceder) {

    NODO x;
    int voa = -1;
    int nivel = 0;

    // Inicialización
    *criterio = 0;
    *generar = 0;
    *solucion = 0;
    *mashermanos = 0;
    *retroceder = 0;

    x.nivel = 0;
    x.bact = 0;
    for (int i = 0; i < N; i++) {
        x.tupla[i] = -1;
        x.usadas[i] = 0;
    }
    s->bact = -1;
    x.tupla[x.nivel] = -1;

    do {
        Generar_Lento(&x, B, generar);
        *nNodos += 1;

        // Si Solución (nivel, s) AND (bact > voa)
        if (Solucion_Lento(x, solucion, criterio) && (x.bact > voa)) {
            *criterio += 1;
            *nNodos -= 1;
            voa = x.bact;
            *s = x;
        }

        // Si Criterio (nivel, s) AND (nivel < n-1)
        if (Criterio_Lento(x, criterio) && (x.nivel < N - 1)) {
            *criterio += 1;
            nivel++;
            x.nivel = nivel;
            x.tupla[nivel] = -1;
        }

        // Mientras NOT MasHermanos(nivel, s) AND (nivel >= 0)
        while (!MasHermanos_Lento(x, mashermanos) && (nivel >= 0)) {
            Retroceder_Lento(&x, B, retroceder);
            *nNodos -= 1;
            *criterio += 1;
            nivel = x.nivel;
        }
    } while (nivel >= 0);
}